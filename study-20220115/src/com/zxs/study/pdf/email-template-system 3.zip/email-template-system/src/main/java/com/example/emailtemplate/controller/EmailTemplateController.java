package com.example.emailtemplate.controller;

import com.example.emailtemplate.entity.EmailTemplate;
import com.example.emailtemplate.entity.ScheduledTask;
import com.example.emailtemplate.repository.ScheduledTaskRepository;
import com.example.emailtemplate.service.EmailTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@RequestMapping("/templates")
public class EmailTemplateController {

    private final EmailTemplateService emailTemplateService;
    private final ScheduledTaskRepository scheduledTaskRepository;

    @GetMapping
    public String listTemplates(Model model) {
        model.addAttribute("templates", emailTemplateService.findAll());
        return "template/list";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("template", new EmailTemplate());
        return "template/form";
    }

    @PostMapping
    public String save(@ModelAttribute EmailTemplate template, @RequestParam(required = false) String timezone) {
        // 保存模板
        EmailTemplate savedTemplate = emailTemplateService.save(template);
        
        // 处理定时任务
        handleScheduleSettings(savedTemplate, timezone);
        
        return "redirect:/templates";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        EmailTemplate template = emailTemplateService.findById(id);
        model.addAttribute("template", template);
        
        // 查找该模板的最新调度任务记录
        if (template.getCronExpression() != null && !template.getCronExpression().isEmpty()) {
            try {
                ScheduledTask latestTask = scheduledTaskRepository.findTopByTemplateIdOrderByCreatedTimeDesc(id);
                if (latestTask != null && latestTask.getTimezone() != null) {
                    model.addAttribute("timezone", latestTask.getTimezone());
                }
            } catch (Exception e) {
                // 忽略错误，使用默认时区
                System.out.println("获取时区信息时出错: " + e.getMessage());
            }
        }
        
        return "template/form";
    }

    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id, @ModelAttribute EmailTemplate template, @RequestParam(required = false) String timezone) {
        // 更新模板
        EmailTemplate updatedTemplate = emailTemplateService.update(id, template);
        
        // 处理定时任务
        handleScheduleSettings(updatedTemplate, timezone);
        
        return "redirect:/templates";
    }
    
    /**
     * 处理定时设置
     */
    private void handleScheduleSettings(EmailTemplate template, String timezone) {
        // 如果有Cron表达式，则设置定时任务
        if (template.getCronExpression() != null && !template.getCronExpression().isEmpty() && template.isActive()) {
            try {
                System.out.println("为模板 ID " + template.getId() + " 设置定时任务，Cron表达式: " + template.getCronExpression() + ", 时区: " + timezone);
                emailTemplateService.scheduleEmail(template.getId(), template.getCronExpression(), timezone);
            } catch (Exception e) {
                System.err.println("设置定时任务失败: " + e.getMessage());
                e.printStackTrace();
            }
        } else if (template.getCronExpression() == null || template.getCronExpression().isEmpty()) {
            // 如果没有Cron表达式，取消现有的定时任务
            try {
                System.out.println("取消模板 ID " + template.getId() + " 的定时任务");
                emailTemplateService.cancelScheduledEmail(template.getId());
            } catch (Exception e) {
                System.err.println("取消定时任务失败: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        // 先取消定时任务
        try {
            emailTemplateService.cancelScheduledEmail(id);
        } catch (Exception e) {
            System.err.println("取消定时任务失败: " + e.getMessage());
        }
        
        // 删除模板
        emailTemplateService.delete(id);
        return "redirect:/templates";
    }

    @PostMapping("/{id}/send")
    public String sendEmail(@PathVariable Long id) {
        emailTemplateService.sendEmail(id);
        return "redirect:/templates";
    }

    @PostMapping("/{id}/schedule")
    public String scheduleEmail(@PathVariable Long id, @RequestParam String cronExpression, @RequestParam(required = false) String timezone) {
        // 获取模板
        EmailTemplate template = emailTemplateService.findById(id);
        // 设置Cron表达式
        template.setCronExpression(cronExpression);
        // 确保模板是激活的
        template.setActive(true);
        // 保存模板
        emailTemplateService.update(id, template);
        // 调度任务
        emailTemplateService.scheduleEmail(id, cronExpression, timezone);
        return "redirect:/templates";
    }
    
    /**
     * 获取模板详情，包括模板信息和邮件内容
     */
    @GetMapping("/{id}/details")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getTemplateDetails(@PathVariable Long id) {
        try {
            EmailTemplate template = emailTemplateService.findById(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("id", template.getId());
            response.put("name", template.getName());
            response.put("subject", template.getSubject());
            response.put("content", template.getContent());
            response.put("recipientList", template.getRecipientList());
            response.put("cronExpression", template.getCronExpression());
            response.put("active", template.isActive());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to get template details: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }
} 