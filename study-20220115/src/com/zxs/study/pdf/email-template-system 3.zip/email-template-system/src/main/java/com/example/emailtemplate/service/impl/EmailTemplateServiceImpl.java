package com.example.emailtemplate.service.impl;

import com.example.emailtemplate.entity.EmailSendLog;
import com.example.emailtemplate.entity.EmailTemplate;
import com.example.emailtemplate.entity.ScheduledTask;
import com.example.emailtemplate.repository.EmailSendLogRepository;
import com.example.emailtemplate.repository.EmailTemplateRepository;
import com.example.emailtemplate.repository.ScheduledTaskRepository;
import com.example.emailtemplate.service.EmailTemplateService;
import lombok.RequiredArgsConstructor;
import org.quartz.*;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Value;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityNotFoundException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;
import com.example.emailtemplate.job.EmailJob;
import org.quartz.CronExpression;
import java.util.Calendar;

@Service
@RequiredArgsConstructor
public class EmailTemplateServiceImpl implements EmailTemplateService {

    private final EmailTemplateRepository emailTemplateRepository;
    private final EmailSendLogRepository emailSendLogRepository;
    private final ScheduledTaskRepository scheduledTaskRepository;
    private final JavaMailSender mailSender;
    private final Scheduler scheduler;
    
    @Value("${spring.mail.username}")
    private String fromEmail;

    @Override
    @Transactional
    public EmailTemplate save(EmailTemplate template) {
        return emailTemplateRepository.save(template);
    }

    @Override
    @Transactional
    public EmailTemplate update(Long id, EmailTemplate template) {
        EmailTemplate existingTemplate = findById(id);
        existingTemplate.setName(template.getName());
        existingTemplate.setSubject(template.getSubject());
        existingTemplate.setContent(template.getContent());
        existingTemplate.setRecipientList(template.getRecipientList());
        existingTemplate.setCronExpression(template.getCronExpression());
        existingTemplate.setActive(template.isActive());
        return emailTemplateRepository.save(existingTemplate);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        emailTemplateRepository.deleteById(id);
    }

    @Override
    public EmailTemplate findById(Long id) {
        return emailTemplateRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Email template not found with id: " + id));
    }

    @Override
    public List<EmailTemplate> findAll() {
        return emailTemplateRepository.findAll();
    }

    @Override
    @Transactional
    public void sendEmail(Long templateId) {
        EmailTemplate template = findById(templateId);
        
        // 创建发送日志
        EmailSendLog log = new EmailSendLog(
            templateId, 
            template.getName(), 
            template.getRecipientList(), 
            template.getSubject()
        );
        
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            
            String[] recipients = template.getRecipientList().split(",");
            helper.setTo(recipients);
            helper.setSubject(template.getSubject());
            helper.setText(template.getContent(), true);
            helper.setFrom(fromEmail);
            
            mailSender.send(message);
            
            // 标记为成功并保存日志
            log.markAsSuccess();
            emailSendLogRepository.save(log);
            
        } catch (MessagingException e) {
            // 标记为失败并保存日志
            log.markAsFailed(e.getMessage());
            emailSendLogRepository.save(log);
            
            throw new RuntimeException("Failed to send email", e);
        }
    }

    @Override
    @Transactional
    public void scheduleEmail(Long templateId, String cronExpression) {
        scheduleEmail(templateId, cronExpression, null);
    }

    @Override
    @Transactional
    public void scheduleEmail(Long templateId, String cronExpression, String timezone) {
        try {
            // 修复Cron表达式
            String fixedCronExpression = fixCronExpression(cronExpression);
            System.out.println("原始Cron表达式: " + cronExpression);
            System.out.println("修复后Cron表达式: " + fixedCronExpression);
            System.out.println("时区: " + (timezone != null ? timezone : "默认系统时区"));
            
            // 先尝试删除已存在的任务
            try {
                TriggerKey triggerKey = TriggerKey.triggerKey("emailTrigger-" + templateId);
                JobKey jobKey = JobKey.jobKey("emailJob-" + templateId);
                
                // 如果触发器存在，先删除
                if (scheduler.checkExists(triggerKey)) {
                    scheduler.unscheduleJob(triggerKey);
                    System.out.println("已删除现有触发器: " + triggerKey);
                }
                
                // 如果任务存在，也删除
                if (scheduler.checkExists(jobKey)) {
                    scheduler.deleteJob(jobKey);
                    System.out.println("已删除现有任务: " + jobKey);
                }
            } catch (Exception e) {
                // 忽略删除过程中的错误
                System.out.println("删除现有任务时出错: " + e.getMessage());
            }
            
            // 创建新任务
            JobDetail jobDetail = JobBuilder.newJob(EmailJob.class)
                    .withIdentity("emailJob-" + templateId)
                    .usingJobData("templateId", templateId)
                    .build();

            // 验证Cron表达式是否有效
            try {
                CronExpression.validateExpression(fixedCronExpression);
                System.out.println("Cron表达式验证通过: " + fixedCronExpression);
            } catch (Exception e) {
                throw new RuntimeException("无效的Cron表达式: " + fixedCronExpression, e);
            }
            
            // 检查Cron表达式是否会在未来触发
            LocalDateTime nextFireTime = null;
            try {
                CronExpression cronExp = new CronExpression(fixedCronExpression);
                
                // 使用指定的时区或默认时区
                ZoneId zoneId = timezone != null && !timezone.isEmpty() 
                    ? ZoneId.of(timezone) 
                    : ZoneId.systemDefault();
                
                // 获取当前时间（考虑时区）
                ZonedDateTime now = ZonedDateTime.now(zoneId);
                Date nowDate = Date.from(now.toInstant());
                
                Date nextValidTime = cronExp.getNextValidTimeAfter(nowDate);
                if (nextValidTime == null) {
                    System.out.println("警告：基于Cron表达式 '" + fixedCronExpression + "' 的触发器可能永远不会触发，尝试修复...");
                    
                    // 检查是否是单次执行的表达式（7个字段，包含年份）
                    String[] parts = fixedCronExpression.split("\\s+");
                    if (parts.length == 7) {
                        try {
                            // 可能是年份超出范围（Quartz支持到2099年），尝试调整年份
                            int year = Integer.parseInt(parts[6]);
                            int currentYear = java.time.Year.now().getValue();
                            
                            // 测试用当前年份
                            parts[6] = String.valueOf(currentYear);
                            String testCronWithCurrentYear = String.join(" ", parts);
                            
                            CronExpression testCron = new CronExpression(testCronWithCurrentYear);
                            Date testTime = testCron.getNextValidTimeAfter(nowDate);
                            
                            if (testTime != null) {
                                // 当前年份有效，使用它
                                fixedCronExpression = testCronWithCurrentYear;
                                nextValidTime = testTime;
                                System.out.println("已将年份调整为当前年份：" + fixedCronExpression);
                            } else {
                                // 尝试用下一年
                                parts[6] = String.valueOf(currentYear + 1);
                                String testCronWithNextYear = String.join(" ", parts);
                                
                                testCron = new CronExpression(testCronWithNextYear);
                                testTime = testCron.getNextValidTimeAfter(nowDate);
                                
                                if (testTime != null) {
                                    // 下一年有效，使用它
                                    fixedCronExpression = testCronWithNextYear;
                                    nextValidTime = testTime;
                                    System.out.println("已将年份调整为下一年：" + fixedCronExpression);
                                }
                            }
                        } catch (Exception e) {
                            System.out.println("尝试修复年份失败：" + e.getMessage());
                        }
                    }
                    
                    // 如果调整后仍然无效，创建一个简单的每日执行表达式（5分钟后执行）
                    if (nextValidTime == null) {
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(nowDate);
                        cal.add(Calendar.MINUTE, 5);
                        
                        int minute = cal.get(Calendar.MINUTE);
                        int hour = cal.get(Calendar.HOUR_OF_DAY);
                        
                        fixedCronExpression = String.format("0 %d %d * * ?", minute, hour);
                        
                        CronExpression simpleCron = new CronExpression(fixedCronExpression);
                        nextValidTime = simpleCron.getNextValidTimeAfter(nowDate);
                        
                        System.out.println("创建了简单的每日执行表达式：" + fixedCronExpression);
                    }
                    
                    // 如果所有尝试都失败，则抛出异常
                    if (nextValidTime == null) {
                        throw new RuntimeException("基于Cron表达式 '" + fixedCronExpression + "' 的触发器将永远不会触发");
                    }
                }
                
                System.out.println("下一次触发时间: " + nextValidTime);
                
                // 转换为LocalDateTime
                nextFireTime = nextValidTime.toInstant()
                    .atZone(zoneId)
                    .toLocalDateTime();
                
            } catch (Exception e) {
                throw new RuntimeException("无法解析Cron表达式: " + fixedCronExpression, e);
            }

            // 创建触发器
            TriggerBuilder<Trigger> triggerBuilder = TriggerBuilder.newTrigger()
                    .withIdentity("emailTrigger-" + templateId)
                    .startAt(new Date());

            // 设置时区
            CronScheduleBuilder scheduleBuilder;
            if (timezone != null && !timezone.isEmpty()) {
                scheduleBuilder = CronScheduleBuilder.cronSchedule(fixedCronExpression)
                    .inTimeZone(java.util.TimeZone.getTimeZone(timezone));
            } else {
                scheduleBuilder = CronScheduleBuilder.cronSchedule(fixedCronExpression);
            }
            
            triggerBuilder.withSchedule(scheduleBuilder);
            
            CronTrigger trigger = (CronTrigger) triggerBuilder.build();

            // 调度任务
            scheduler.scheduleJob(jobDetail, trigger);
            System.out.println("成功调度任务，触发器: emailTrigger-" + templateId);
            
            // 更新模板的Cron表达式
            EmailTemplate template = findById(templateId);
            template.setCronExpression(fixedCronExpression);
            emailTemplateRepository.save(template);
            System.out.println("已更新模板的Cron表达式: " + fixedCronExpression);
            
            // 查找是否已存在相关的调度任务记录
            List<ScheduledTask> existingTasks = scheduledTaskRepository.findByTemplateIdAndStatus(templateId, "SCHEDULED");
            
            // 获取下一次触发时间
            Date nextFireTimeDate = trigger.getNextFireTime();
            
            if (!existingTasks.isEmpty()) {
                // 如果已存在任务记录，更新它
                ScheduledTask existingTask = existingTasks.get(0);
                existingTask.setCronExpression(fixedCronExpression);
                existingTask.setTimezone(timezone);
                existingTask.setNextFireTime(nextFireTimeDate != null ? 
                    LocalDateTime.ofInstant(nextFireTimeDate.toInstant(), ZoneId.systemDefault()) : null);
                existingTask.setUpdatedTime(LocalDateTime.now());
                existingTask.setStatus("SCHEDULED");
                scheduledTaskRepository.save(existingTask);
                System.out.println("已更新现有调度任务记录");
            } else {
                // 否则创建新的任务记录
                ScheduledTask scheduledTask = new ScheduledTask(
                    templateId,
                    template.getName(),
                    fixedCronExpression,
                    nextFireTimeDate != null ? 
                        LocalDateTime.ofInstant(nextFireTimeDate.toInstant(), ZoneId.systemDefault()) : null,
                    timezone
                );
                scheduledTaskRepository.save(scheduledTask);
                System.out.println("已创建新的调度任务记录");
            }
            
        } catch (SchedulerException e) {
            e.printStackTrace();
            throw new RuntimeException("调度邮件失败: " + e.getMessage(), e);
        }
    }
    
    /**
     * 修复Cron表达式
     */
    private String fixCronExpression(String cronExpression) {
        if (cronExpression == null || cronExpression.trim().isEmpty()) {
            throw new IllegalArgumentException("Cron expression cannot be empty");
        }
        
        String[] parts = cronExpression.trim().split("\\s+");
        
        // 检查是否是标准的Quartz Cron表达式
        if (parts.length == 7) {
            // 7部分Cron表达式: 秒 分 时 日 月 周 年
            // 确保日和周字段中至少有一个是 '?'
            if (!parts[3].equals("?") && !parts[5].equals("?")) {
                // 如果两者都不是 '?'，将周字段设为 '?'
                parts[5] = "?";
            }
            
            // 检查年份是否有效（确保不是过去的年份）
            try {
                int year = Integer.parseInt(parts[6]);
                int currentYear = java.time.Year.now().getValue();
                if (year < currentYear) {
                    parts[6] = String.valueOf(currentYear);
                    System.out.println("已将过去的年份 " + year + " 调整为当前年份 " + currentYear);
                }
                
                // 检查月份和日期是否有效
                if (!parts[3].equals("?") && !parts[3].equals("*")) {
                    try {
                        int day = Integer.parseInt(parts[3]);
                        int month = Integer.parseInt(parts[4]);
                        
                        if (month < 1 || month > 12) {
                            // 月份无效，调整为当前月份
                            month = java.time.LocalDate.now().getMonthValue();
                            parts[4] = String.valueOf(month);
                            System.out.println("已将无效的月份调整为当前月份: " + month);
                        }
                        
                        // 计算月份的最大天数
                        java.time.YearMonth yearMonth = java.time.YearMonth.of(year, month);
                        int maxDays = yearMonth.lengthOfMonth();
                        
                        if (day < 1 || day > maxDays) {
                            // 日期无效，调整为当月有效日期（默认为1日）
                            day = Math.min(Math.max(1, day), maxDays);
                            parts[3] = String.valueOf(day);
                            System.out.println("已将无效的日期 " + parts[3] + " 调整为有效值: " + day);
                        }
                    } catch (NumberFormatException e) {
                        // 忽略非数字值，如 L, W 等特殊字符
                    }
                }
            } catch (NumberFormatException e) {
                // 如果年份不是数字，使用当前年份
                parts[6] = String.valueOf(java.time.Year.now().getValue());
                System.out.println("已将非数字年份调整为当前年份: " + parts[6]);
            }
            
            return String.join(" ", parts);
        } else if (parts.length == 6) {
            // 6部分Cron表达式: 秒 分 时 日 月 周
            // 确保日和周字段中至少有一个是 '?'
            if (!parts[3].equals("?") && !parts[5].equals("?")) {
                // 如果两者都不是 '?'，将周字段设为 '?'
                parts[5] = "?";
            }
            return String.join(" ", parts);
        } else if (parts.length == 5) {
            // 5部分Cron表达式: 分 时 日 月 周
            // 添加秒字段
            String[] newParts = new String[6];
            newParts[0] = "0"; // 秒设为0
            System.arraycopy(parts, 0, newParts, 1, 5);
            parts = newParts;
            
            // 确保日和周字段中至少有一个是 '?'
            if (!parts[3].equals("?") && !parts[5].equals("?")) {
                parts[5] = "?";
            }
            return String.join(" ", parts);
        }
        
        return cronExpression;
    }

    @Override
    @Transactional
    public void cancelScheduledEmail(Long templateId) {
        try {
            // 定义触发器和任务的键
            TriggerKey triggerKey = TriggerKey.triggerKey("emailTrigger-" + templateId);
            JobKey jobKey = JobKey.jobKey("emailJob-" + templateId);
            
            // 如果触发器存在，先删除
            if (scheduler.checkExists(triggerKey)) {
                scheduler.unscheduleJob(triggerKey);
                System.out.println("已删除触发器: " + triggerKey);
            }
            
            // 如果任务存在，也删除
            if (scheduler.checkExists(jobKey)) {
                scheduler.deleteJob(jobKey);
                System.out.println("已删除任务: " + jobKey);
            }
            
            // 更新模板，清除Cron表达式
            try {
                EmailTemplate template = findById(templateId);
                template.setCronExpression(null);
                emailTemplateRepository.save(template);
                System.out.println("已清除模板的Cron表达式");
            } catch (Exception e) {
                System.out.println("清除模板Cron表达式时出错: " + e.getMessage());
            }
            
            // 更新相关的调度任务记录状态
            List<ScheduledTask> tasks = scheduledTaskRepository.findByTemplateId(templateId);
            for (ScheduledTask task : tasks) {
                if ("SCHEDULED".equals(task.getStatus())) {
                    task.setStatus("CANCELLED");
                    task.setUpdatedTime(LocalDateTime.now());
                    scheduledTaskRepository.save(task);
                }
            }
            System.out.println("已更新调度任务记录状态");
            
        } catch (SchedulerException e) {
            e.printStackTrace();
            throw new RuntimeException("取消调度任务失败: " + e.getMessage(), e);
        }
    }
} 