package com.example.emailtemplate.service;

import com.example.emailtemplate.entity.EmailTemplate;
import java.util.List;

public interface EmailTemplateService {
    EmailTemplate save(EmailTemplate template);
    EmailTemplate update(Long id, EmailTemplate template);
    void delete(Long id);
    EmailTemplate findById(Long id);
    List<EmailTemplate> findAll();
    void sendEmail(Long templateId);
    void scheduleEmail(Long templateId, String cronExpression);
    void scheduleEmail(Long templateId, String cronExpression, String timezone);
    void cancelScheduledEmail(Long templateId);
} 