package com.example.emailtemplate.controller;

import com.example.emailtemplate.entity.ScheduledTask;
import com.example.emailtemplate.repository.EmailSendLogRepository;
import com.example.emailtemplate.repository.ScheduledTaskRepository;
import com.example.emailtemplate.service.EmailTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@Controller
@RequiredArgsConstructor
@RequestMapping("/logs")
public class LogController {

    private final EmailSendLogRepository emailSendLogRepository;
    private final ScheduledTaskRepository scheduledTaskRepository;
    private final EmailTemplateService emailTemplateService;

    @GetMapping("/email")
    public String emailLogs(Model model) {
        model.addAttribute("logs", emailSendLogRepository.findAll());
        return "logs/email";
    }

    @GetMapping("/tasks")
    public String scheduledTasks(Model model) {
        model.addAttribute("tasks", scheduledTaskRepository.findAll());
        return "logs/tasks";
    }
} 