package com.example.emailtemplate.controller;

import com.example.emailtemplate.entity.EmailSendLog;
import com.example.emailtemplate.entity.EmailTemplate;
import com.example.emailtemplate.entity.ScheduledTask;
import com.example.emailtemplate.repository.EmailSendLogRepository;
import com.example.emailtemplate.repository.EmailTemplateRepository;
import com.example.emailtemplate.repository.ScheduledTaskRepository;
import com.example.emailtemplate.service.EmailTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
@RequestMapping("/tasks")
public class TaskController {

    private final ScheduledTaskRepository scheduledTaskRepository;
    private final EmailTemplateService emailTemplateService;
    private final EmailSendLogRepository emailSendLogRepository;
    private final EmailTemplateRepository emailTemplateRepository;
    
    // 添加一个测试方法，确认控制器能够正常响应请求
    @GetMapping("/test")
    @ResponseBody
    public String testController() {
        System.out.println("TaskController.testController() 被调用");
        
        // 打印所有任务的信息，帮助调试
        List<ScheduledTask> tasks = scheduledTaskRepository.findAll();
        System.out.println("当前共有 " + tasks.size() + " 个任务");
        for (ScheduledTask task : tasks) {
            System.out.println("任务ID: " + task.getId() + ", 状态: " + task.getStatus() + ", 模板ID: " + task.getTemplateId());
        }
        
        return "TaskController is working!";
    }

    @GetMapping("/{id}/edit")
    public String editTask(@PathVariable Long id, Model model) {
        System.out.println("TaskController.editTask() 被调用，任务ID: " + id);
        try {
            ScheduledTask task = scheduledTaskRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("任务不存在"));
            System.out.println("找到任务: " + task.getId() + ", 状态: " + task.getStatus() + ", 模板ID: " + task.getTemplateId());
            model.addAttribute("task", task);
            return "logs/task-edit";
        } catch (Exception e) {
            // 记录错误并重定向到任务列表页面
            System.err.println("编辑任务时出错: " + e.getMessage());
            return "redirect:/logs/tasks";
        }
    }
    
    @PostMapping("/{id}/update")
    public String updateTask(@PathVariable Long id, @RequestParam String cronExpression, 
                            @RequestParam(required = false) String timezone) {
        System.out.println("TaskController.updateTask() 被调用，任务ID: " + id + ", cronExpression: " + cronExpression + ", timezone: " + timezone);
        try {
            ScheduledTask task = scheduledTaskRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("任务不存在"));
            System.out.println("找到任务: " + task.getId() + ", 状态: " + task.getStatus() + ", 模板ID: " + task.getTemplateId());
            
            // 先取消原有的调度任务
            try {
                System.out.println("尝试取消原有调度任务");
                emailTemplateService.cancelScheduledEmail(task.getTemplateId());
                System.out.println("成功取消原有调度任务");
            } catch (Exception e) {
                System.err.println("取消原有调度任务时出错: " + e.getMessage());
                // 继续执行，不中断流程
            }
            
            // 更新任务信息
            task.setCronExpression(cronExpression);
            task.setTimezone(timezone);
            task.setUpdatedTime(LocalDateTime.now());
            task.setStatus("SCHEDULED"); // 确保状态为已调度
            scheduledTaskRepository.save(task);
            System.out.println("成功更新任务信息");
            
            // 重新调度任务
            try {
                System.out.println("尝试重新调度任务");
                emailTemplateService.scheduleEmail(task.getTemplateId(), cronExpression, timezone);
                System.out.println("成功重新调度任务");
            } catch (Exception e) {
                System.err.println("重新调度任务时出错: " + e.getMessage());
                // 继续执行，不中断流程
            }
            
            return "redirect:/logs/tasks";
        } catch (Exception e) {
            System.err.println("更新任务失败: " + e.getMessage());
            return "redirect:/logs/tasks";
        }
    }
    
    @PostMapping("/{id}/delete")
    public String deleteTask(@PathVariable Long id) {
        System.out.println("TaskController.deleteTask() 被调用，任务ID: " + id);
        try {
            ScheduledTask task = scheduledTaskRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("任务不存在"));
            System.out.println("找到任务: " + task.getId() + ", 状态: " + task.getStatus() + ", 模板ID: " + task.getTemplateId());
            
            // 取消调度任务
            try {
                System.out.println("尝试取消调度任务");
                emailTemplateService.cancelScheduledEmail(task.getTemplateId());
                System.out.println("成功取消调度任务");
            } catch (Exception e) {
                System.err.println("取消调度任务时出错: " + e.getMessage());
                // 继续执行，不中断流程
            }
            
            // 更新任务状态为已取消
            task.setStatus("CANCELLED");
            task.setUpdatedTime(LocalDateTime.now());
            scheduledTaskRepository.save(task);
            System.out.println("成功更新任务状态为已取消");
            
            return "redirect:/logs/tasks";
        } catch (Exception e) {
            System.err.println("删除任务失败: " + e.getMessage());
            return "redirect:/logs/tasks";
        }
    }
    
    // 添加 GET 请求处理方法来处理删除操作，以防 POST 请求不起作用
    @GetMapping("/{id}/delete")
    public String deleteTaskGet(@PathVariable Long id) {
        System.out.println("TaskController.deleteTaskGet() 被调用，任务ID: " + id);
        return deleteTask(id);
    }
    
    /**
     * 获取任务详情，包括任务信息和邮件模板内容
     */
    @GetMapping("/{id}/details")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getTaskDetails(@PathVariable Long id) {
        System.out.println("TaskController.getTaskDetails() 被调用，任务ID: " + id);
        try {
            // 获取任务信息
            ScheduledTask task = scheduledTaskRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("任务不存在"));
            System.out.println("找到任务: " + task.getId() + ", 状态: " + task.getStatus() + ", 模板ID: " + task.getTemplateId());
            
            // 获取邮件模板信息
            Optional<EmailTemplate> templateOptional = emailTemplateRepository.findById(task.getTemplateId());
            System.out.println("邮件模板是否存在: " + templateOptional.isPresent());
            
            // 格式化日期时间
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            
            // 构建响应数据
            Map<String, Object> responseData = new HashMap<>();
            
            // 添加任务信息
            responseData.put("id", task.getId());
            responseData.put("templateId", task.getTemplateId());
            responseData.put("templateName", task.getTemplateName());
            responseData.put("cronExpression", task.getCronExpression());
            responseData.put("timezone", task.getTimezone());
            responseData.put("status", task.getStatus());
            
            if (task.getNextFireTime() != null) {
                responseData.put("nextFireTime", task.getNextFireTime().format(formatter));
            } else {
                responseData.put("nextFireTime", null);
            }
            
            if (task.getCreatedTime() != null) {
                responseData.put("createdTime", task.getCreatedTime().format(formatter));
            }
            
            if (task.getUpdatedTime() != null) {
                responseData.put("updatedTime", task.getUpdatedTime().format(formatter));
            }
            
            // 添加邮件内容
            if (templateOptional.isPresent()) {
                EmailTemplate template = templateOptional.get();
                responseData.put("emailContent", template.getContent());
            } else {
                responseData.put("emailContent", null);
            }
            
            return ResponseEntity.ok(responseData);
        } catch (Exception e) {
            System.err.println("获取任务详情失败: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "获取任务详情失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }
} 