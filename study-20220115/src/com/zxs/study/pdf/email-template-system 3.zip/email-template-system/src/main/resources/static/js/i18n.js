// 当前语言
let currentLang = 'zh';

// 语言切换事件监听器列表
const languageChangeListeners = [];

// 添加语言切换监听器
function addLanguageChangeListener(listener) {
    languageChangeListeners.push(listener);
}

// 切换语言
function toggleLanguage() {
    currentLang = currentLang === 'zh' ? 'en' : 'zh';
    updateLanguage();
    // 触发所有监听器
    languageChangeListeners.forEach(listener => listener(currentLang));
    // 更新切换按钮文本
    const langToggle = document.getElementById('langToggle');
    if (langToggle) {
        langToggle.textContent = currentLang === 'zh' ? 'EN' : '中';
    }
    // 保存语言偏好到localStorage
    localStorage.setItem('preferredLanguage', currentLang);
}

// 更新页面语言
function updateLanguage() {
    document.querySelectorAll('[data-' + currentLang + ']').forEach(element => {
        element.textContent = element.getAttribute('data-' + currentLang);
    });
}

// 获取当前语言
function getCurrentLanguage() {
    return currentLang;
}

// 初始化语言设置
function initializeLanguage() {
    // 从localStorage获取保存的语言偏好
    const savedLang = localStorage.getItem('preferredLanguage');
    if (savedLang && savedLang !== currentLang) {
        currentLang = savedLang;
        updateLanguage();
        languageChangeListeners.forEach(listener => listener(currentLang));
    }
}

// 添加语言切换按钮到页面
function addLanguageSwitch() {
    const switchDiv = document.createElement('div');
    switchDiv.className = 'language-switch';
    switchDiv.innerHTML = `
        <button class="btn btn-sm btn-outline-secondary" onclick="toggleLanguage()" id="langToggle">
            ${currentLang === 'zh' ? 'EN' : '中'}
        </button>
    `;
    document.body.appendChild(switchDiv);
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    initializeLanguage();
    addLanguageSwitch();
}); 