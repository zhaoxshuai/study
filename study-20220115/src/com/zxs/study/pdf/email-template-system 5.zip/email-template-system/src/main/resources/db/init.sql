-- 创建数据库
CREATE DATABASE IF NOT EXISTS email_template DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE email_template;

-- 创建邮件模板表
CREATE TABLE IF NOT EXISTS email_templates (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL COMMENT '模板名称',
    subject VARCHAR(255) NOT NULL COMMENT '邮件主题',
    content TEXT NOT NULL COMMENT '邮件内容',
    cron_expression VARCHAR(100) COMMENT '定时任务表达式',
    is_active BOOLEAN DEFAULT TRUE COMMENT '是否激活',
    recipient_list TEXT NOT NULL COMMENT '收件人列表，逗号分隔',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邮件模板表';

-- 创建定时任务执行记录表
CREATE TABLE IF NOT EXISTS email_send_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    template_id BIGINT NOT NULL COMMENT '模板ID',
    status VARCHAR(20) NOT NULL COMMENT '发送状态：SUCCESS/FAILED',
    error_message TEXT COMMENT '错误信息',
    send_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
    FOREIGN KEY (template_id) REFERENCES email_templates(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邮件发送日志表';

-- 创建定时任务配置表
CREATE TABLE IF NOT EXISTS scheduled_tasks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    template_id BIGINT NOT NULL COMMENT '模板ID',
    cron_expression VARCHAR(100) NOT NULL COMMENT '定时表达式',
    last_execution TIMESTAMP NULL COMMENT '上次执行时间',
    next_execution TIMESTAMP NULL COMMENT '下次执行时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    FOREIGN KEY (template_id) REFERENCES email_templates(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定时任务配置表';

-- 插入测试数据
INSERT INTO email_templates (name, subject, content, recipient_list) 
VALUES ('欢迎邮件', '欢迎加入我们', '<h1>欢迎加入我们的团队！</h1><p>这是一封测试邮件。</p>', 'test@example.com');

INSERT INTO email_templates (name, subject, content, recipient_list, cron_expression) 
VALUES ('每日提醒', '每日工作安排', '<h1>今日工作安排</h1><p>请查看您今天的工作安排。</p>', 'daily@example.com', '0 0 9 * * ?'); 