package com.example.emailtemplate.repository;

import com.example.emailtemplate.entity.EmailSendLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmailSendLogRepository extends JpaRepository<EmailSendLog, Long> {
    List<EmailSendLog> findByTemplateId(Long templateId);
    List<EmailSendLog> findTop10ByOrderBySendTimeDesc();
} 