package com.example.emailtemplate.repository;

import com.example.emailtemplate.entity.ScheduledTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ScheduledTaskRepository extends JpaRepository<ScheduledTask, Long> {
    List<ScheduledTask> findByTemplateId(Long templateId);
    List<ScheduledTask> findByTemplateIdAndStatus(Long templateId, String status);
    List<ScheduledTask> findByStatus(String status);
    ScheduledTask findTopByTemplateIdOrderByCreatedTimeDesc(Long templateId);
} 