// 发送邮件
function sendEmail(templateId) {
    console.log('sendEmail called with templateId:', templateId);
    
    if (!templateId) {
        console.error('No template ID provided');
        showMessage('danger', getCurrentLanguage() === 'zh' ? '错误' : 'Error', getCurrentLanguage() === 'zh' ? '无效的模板ID' : 'Invalid template ID');
        return;
    }

    if (!confirm(getCurrentLanguage() === 'zh' ? '确定要发送此邮件吗？' : 'Are you sure you want to send this email?')) {
        return;
    }

    // 显示加载状态
    showMessage('info', getCurrentLanguage() === 'zh' ? '发送中' : 'Sending', getCurrentLanguage() === 'zh' ? '正在发送邮件，请稍候...' : 'Sending email, please wait...');

    $.ajax({
        url: '/templates/' + templateId + '/send',
        type: 'POST',
        success: function(response) {
            console.log('Ajax success response:', response);
            if (response.success) {
                showMessage('success', getCurrentLanguage() === 'zh' ? '成功' : 'Success', response.message);
            } else {
                let errorMessage = response.message;
                if (response.code === 'TEMPLATE_INACTIVE') {
                    errorMessage = getCurrentLanguage() === 'zh' 
                        ? '邮件模板未激活，无法发送。请先激活模板。' 
                        : 'Email template is inactive. Please activate it first.';
                }
                showMessage('danger', getCurrentLanguage() === 'zh' ? '错误' : 'Error', errorMessage);
            }
        },
        error: function(xhr, status, error) {
            console.error('Ajax error:', {xhr, status, error});
            let errorMessage = getCurrentLanguage() === 'zh' ? '发送邮件失败' : 'Failed to send email';
            if (xhr.responseJSON) {
                if (xhr.responseJSON.code === 'TEMPLATE_INACTIVE') {
                    errorMessage = getCurrentLanguage() === 'zh' 
                        ? '邮件模板未激活，无法发送。请先激活模板。' 
                        : 'Email template is inactive. Please activate it first.';
                } else {
                    errorMessage = xhr.responseJSON.message || errorMessage;
                }
            }
            showMessage('danger', getCurrentLanguage() === 'zh' ? '错误' : 'Error', errorMessage);
        }
    });
}

// 显示消息
function showMessage(type, title, message) {
    console.log('Showing message:', {type, title, message});
    
    // 获取模态框元素
    const modal = document.getElementById('messageModal');
    if (!modal) {
        console.error('Message modal not found');
        return;
    }
    
    const modalTitle = document.getElementById('messageModalLabel');
    const modalBody = document.getElementById('messageModalBody');
    
    // 设置模态框标题和内容
    modalTitle.textContent = title;
    modalBody.innerHTML = `
        <div class="alert alert-${type} mb-0">
            ${message}
        </div>
    `;
    
    // 显示模态框
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    
    // 3秒后自动关闭
    setTimeout(() => {
        bsModal.hide();
    }, 3000);
}

// 页面加载完成后初始化
$(document).ready(function() {
    console.log('Document ready, initializing...');
    
    // 初始化所有工具提示
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // 绑定发送按钮点击事件
    $('.send-email-btn').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const templateId = $(this).data('template-id');
        console.log('Send button clicked for template:', templateId);
        sendEmail(templateId);
    });
}); 