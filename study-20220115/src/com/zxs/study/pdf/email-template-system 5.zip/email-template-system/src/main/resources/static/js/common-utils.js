/**
 * 通用工具类，用于处理模态框和详情展示
 */

/**
 * 显示详情模态框
 * @param {string} modalId - 模态框ID
 * @param {string} loadingId - 加载中元素ID
 * @param {string} contentId - 内容元素ID
 * @param {string} errorId - 错误元素ID
 */
function showDetailModal(modalId, loadingId, contentId, errorId) {
    // 显示模态框
    const modal = new bootstrap.Modal(document.getElementById(modalId));
    modal.show();
    
    // 重置模态框状态
    document.getElementById(loadingId).style.display = 'block';
    document.getElementById(contentId).style.display = 'none';
    document.getElementById(errorId).style.display = 'none';
}

/**
 * 获取详情数据
 * @param {string} url - 请求URL
 * @param {Function} successCallback - 成功回调函数
 * @param {string} loadingId - 加载中元素ID
 * @param {string} contentId - 内容元素ID
 * @param {string} errorId - 错误元素ID
 * @param {string} errorMessage - 错误信息
 */
function fetchDetailData(url, successCallback, loadingId, contentId, errorId, errorMessage) {
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(errorMessage);
            }
            return response.json();
        })
        .then(data => {
            // 调用成功回调函数处理数据
            successCallback(data);
            
            // 显示内容
            document.getElementById(loadingId).style.display = 'none';
            document.getElementById(contentId).style.display = 'block';
        })
        .catch(error => {
            console.error(errorMessage + ':', error);
            document.getElementById(loadingId).style.display = 'none';
            document.getElementById(errorId).style.display = 'block';
        });
}

/**
 * 设置元素文本内容
 * @param {string} elementId - 元素ID
 * @param {string} text - 文本内容
 */
function setElementText(elementId, text) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = text || '';
    }
}

/**
 * 设置HTML内容
 * @param {string} elementId - 元素ID
 * @param {string} html - HTML内容
 * @param {string} emptyMessage - 内容为空时显示的消息
 */
function setHtmlContent(elementId, html, emptyMessage) {
    const element = document.getElementById(elementId);
    if (element) {
        if (html) {
            element.innerHTML = html;
        } else {
            element.innerHTML = '<p class="text-muted">' + 
                (getCurrentLanguage() === 'zh' ? emptyMessage.zh : emptyMessage.en) + 
                '</p>';
        }
    }
}

/**
 * 获取状态文本
 * @param {string} status - 状态值
 * @param {Object} statusMap - 状态映射对象
 * @returns {string} 状态文本
 */
function getStatusText(status, statusMap) {
    const currentLang = getCurrentLanguage();
    const langKey = currentLang === 'zh' ? 'zh' : 'en';
    
    if (statusMap[status] && statusMap[status][langKey]) {
        return statusMap[status][langKey];
    }
    
    return status;
}

/**
 * 更新Cron表达式
 * @param {string} templateId - 模板ID
 * @param {string} scheduleTypeSelector - 调度类型选择器
 * @param {string} dateTimeId - 日期时间元素ID
 * @param {string} weekDayId - 星期选择元素ID
 * @param {string} monthDayId - 月份日期选择元素ID
 * @param {string} timezoneId - 时区选择元素ID
 * @param {string} cronExpressionId - Cron表达式元素ID
 * @param {string} timezoneInputId - 时区输入元素ID
 */
function updateCronExpression(templateId, scheduleTypeSelector, dateTimeId, weekDayId, monthDayId, timezoneId, cronExpressionId, timezoneInputId) {
    const scheduleType = document.querySelector(scheduleTypeSelector).value;
    const dateTime = document.getElementById(dateTimeId).value;
    const weekDay = document.getElementById(weekDayId).value;
    const monthDay = document.getElementById(monthDayId).value;
    const timezone = document.getElementById(timezoneId).value;
    
    let cronExp = '';
    
    if (dateTime) {
        // 创建日期对象
        const date = new Date(dateTime);
        
        // 检查日期是否在过去
        const now = new Date();
        const isPastDate = date < now;
        
        // 如果是过去的日期，使用当前时间加5分钟
        const adjustedDate = isPastDate ? new Date(now.getTime() + 5 * 60000) : date;
        
        // 获取日期时间组件
        const minutes = adjustedDate.getMinutes();
        const hours = adjustedDate.getHours();
        const day = adjustedDate.getDate();
        const month = adjustedDate.getMonth() + 1;
        const year = adjustedDate.getFullYear();
        
        // 设置时区值
        document.getElementById(timezoneInputId).value = timezone;
        
        switch(scheduleType) {
            case 'oneTime':
                // 秒 分 时 日 月 周 年
                cronExp = `0 ${minutes} ${hours} ${day} ${month} ? ${year}`;
                if (isPastDate) {
                    console.log("检测到过去的日期，已调整为未来时间: " + cronExp);
                }
                break;
            case 'daily':
                // 秒 分 时 日 月 周
                cronExp = `0 ${minutes} ${hours} * * ?`;
                break;
            case 'weekly':
                // 秒 分 时 日 月 周
                cronExp = `0 ${minutes} ${hours} ? * ${weekDay}`;
                break;
            case 'monthly':
                // 秒 分 时 日 月 周
                cronExp = `0 ${minutes} ${hours} ${monthDay} * ?`;
                break;
        }
    }
    
    document.getElementById(cronExpressionId).value = cronExp;
    console.log(`生成的Cron表达式: ${cronExp}，时区: ${timezone}`);
}

/**
 * 更新月份日期选项
 * @param {HTMLElement} monthDaySelect - 月份日期选择元素
 */
function updateMonthDayOptions(monthDaySelect) {
    const selectedValue = monthDaySelect.value;
    monthDaySelect.innerHTML = '';
    
    for(let i = 1; i <= 31; i++) {
        const option = document.createElement('option');
        option.value = i;
        if (getCurrentLanguage() === 'en') {
            option.textContent = i + getDayOfMonthSuffix(i);
        } else {
            option.textContent = i + '日';
        }
        option.setAttribute('data-en', i + getDayOfMonthSuffix(i));
        option.setAttribute('data-zh', i + '日');
        monthDaySelect.appendChild(option);
    }
    monthDaySelect.value = selectedValue || '1';
}

/**
 * 获取月份日期后缀
 * @param {number} n - 日期
 * @returns {string} 后缀
 */
function getDayOfMonthSuffix(n) {
    if (n >= 11 && n <= 13) return 'th';
    switch (n % 10) {
        case 1:  return 'st';
        case 2:  return 'nd';
        case 3:  return 'rd';
        default: return 'th';
    }
} 