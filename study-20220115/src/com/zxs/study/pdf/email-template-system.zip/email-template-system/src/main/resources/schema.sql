-- 创建email_send_logs表
CREATE TABLE IF NOT EXISTS email_send_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    template_id BIGINT NOT NULL,
    template_name VARCHAR(255) NOT NULL,
    recipients VARCHAR(1000) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    send_time TIMESTAMP NOT NULL,
    status VARCHAR(50) NOT NULL,
    error_message VARCHAR(1000)
);

-- 创建scheduled_tasks表
CREATE TABLE IF NOT EXISTS scheduled_tasks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    template_id BIGINT NOT NULL,
    template_name VARCHAR(255) NOT NULL,
    cron_expression VARCHAR(255) NOT NULL,
    timezone VARCHAR(100) DEFAULT 'Asia/Shanghai',
    next_fire_time TIMESTAMP NOT NULL,
    created_time TIMESTAMP NOT NULL,
    updated_time TIMESTAMP NOT NULL,
    status VARCHAR(50) NOT NULL
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_email_logs_template_id ON email_send_logs(template_id);
CREATE INDEX IF NOT EXISTS idx_email_logs_send_time ON email_send_logs(send_time);
CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_template_id ON scheduled_tasks(template_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_tasks_status ON scheduled_tasks(status); 