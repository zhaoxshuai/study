package com.example.emailtemplate.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "email_send_logs")
@Data
@NoArgsConstructor
public class EmailSendLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "template_id")
    private Long templateId;

    @Column(name = "template_name")
    private String templateName;

    @Column(name = "recipients")
    private String recipients;

    @Column(name = "subject")
    private String subject;

    @Column(name = "send_time")
    private LocalDateTime sendTime;

    @Column(name = "status")
    private String status;

    @Column(name = "error_message", length = 1000)
    private String errorMessage;

    public EmailSendLog(Long templateId, String templateName, String recipients, String subject) {
        this.templateId = templateId;
        this.templateName = templateName;
        this.recipients = recipients;
        this.subject = subject;
        this.sendTime = LocalDateTime.now();
        this.status = "PENDING";
    }

    public void markAsSuccess() {
        this.status = "SUCCESS";
        this.sendTime = LocalDateTime.now();
    }

    public void markAsFailed(String errorMessage) {
        this.status = "FAILED";
        this.errorMessage = errorMessage;
        this.sendTime = LocalDateTime.now();
    }
} 