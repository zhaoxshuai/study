package com.example.emailtemplate.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "scheduled_tasks")
@Data
@NoArgsConstructor
public class ScheduledTask {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "template_id")
    private Long templateId;

    @Column(name = "template_name")
    private String templateName;

    @Column(name = "cron_expression")
    private String cronExpression;

    @Column(name = "timezone")
    private String timezone;

    @Column(name = "next_fire_time")
    private LocalDateTime nextFireTime;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    @Column(name = "status")
    private String status;

    public ScheduledTask(Long templateId, String templateName, String cronExpression, LocalDateTime nextFireTime) {
        this.templateId = templateId;
        this.templateName = templateName;
        this.cronExpression = cronExpression;
        this.nextFireTime = nextFireTime;
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        this.status = "SCHEDULED";
        this.timezone = "Asia/Shanghai"; // 默认使用中国时区
    }

    public ScheduledTask(Long templateId, String templateName, String cronExpression, LocalDateTime nextFireTime, String timezone) {
        this(templateId, templateName, cronExpression, nextFireTime);
        this.timezone = timezone != null ? timezone : "Asia/Shanghai";
    }

    public void updateNextFireTime(LocalDateTime nextFireTime) {
        this.nextFireTime = nextFireTime;
        this.updatedTime = LocalDateTime.now();
    }

    public void markAsCompleted() {
        this.status = "COMPLETED";
        this.updatedTime = LocalDateTime.now();
    }

    public void markAsFailed() {
        this.status = "FAILED";
        this.updatedTime = LocalDateTime.now();
    }
} 