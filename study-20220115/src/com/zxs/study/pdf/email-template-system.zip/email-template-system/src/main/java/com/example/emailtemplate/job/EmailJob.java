package com.example.emailtemplate.job;

import com.example.emailtemplate.entity.ScheduledTask;
import com.example.emailtemplate.repository.ScheduledTaskRepository;
import com.example.emailtemplate.service.EmailTemplateService;
import lombok.RequiredArgsConstructor;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class EmailJob implements Job {

    private final EmailTemplateService emailTemplateService;
    private final ScheduledTaskRepository scheduledTaskRepository;

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        Long templateId = context.getJobDetail().getJobDataMap().getLong("templateId");
        
        // 查找对应的调度任务记录
        List<ScheduledTask> tasks = scheduledTaskRepository.findByTemplateIdAndStatus(templateId, "SCHEDULED");
        
        try {
            // 发送邮件
            emailTemplateService.sendEmail(templateId);
            
            // 更新任务状态
            if (!tasks.isEmpty()) {
                ScheduledTask task = tasks.get(0);
                task.markAsCompleted();
                scheduledTaskRepository.save(task);
            }
            
        } catch (Exception e) {
            // 更新任务状态为失败
            if (!tasks.isEmpty()) {
                ScheduledTask task = tasks.get(0);
                task.markAsFailed();
                scheduledTaskRepository.save(task);
            }
            
            throw new JobExecutionException(e);
        }
    }
} 