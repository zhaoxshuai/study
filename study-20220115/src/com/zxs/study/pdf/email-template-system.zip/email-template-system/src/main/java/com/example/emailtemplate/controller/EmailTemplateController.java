package com.example.emailtemplate.controller;

import com.example.emailtemplate.entity.EmailTemplate;
import com.example.emailtemplate.entity.ScheduledTask;
import com.example.emailtemplate.repository.ScheduledTaskRepository;
import com.example.emailtemplate.service.EmailTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@RequestMapping("/templates")
public class EmailTemplateController {

    private final EmailTemplateService emailTemplateService;
    private final ScheduledTaskRepository scheduledTaskRepository;

    @GetMapping
    public String listTemplates(Model model) {
        model.addAttribute("templates", emailTemplateService.findAll());
        return "template/list";
    }

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("template", new EmailTemplate());
        return "template/form";
    }

    @PostMapping
    public String save(@ModelAttribute EmailTemplate template) {
        emailTemplateService.save(template);
        return "redirect:/templates";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        EmailTemplate template = emailTemplateService.findById(id);
        model.addAttribute("template", template);
        
        // 查找该模板的最新调度任务记录
        if (template.getCronExpression() != null && !template.getCronExpression().isEmpty()) {
            try {
                ScheduledTask latestTask = scheduledTaskRepository.findTopByTemplateIdOrderByCreatedTimeDesc(id);
                if (latestTask != null && latestTask.getTimezone() != null) {
                    model.addAttribute("timezone", latestTask.getTimezone());
                }
            } catch (Exception e) {
                // 忽略错误，使用默认时区
                System.out.println("获取时区信息时出错: " + e.getMessage());
            }
        }
        
        return "template/form";
    }

    @PostMapping("/edit/{id}")
    public String update(@PathVariable Long id, @ModelAttribute EmailTemplate template) {
        emailTemplateService.update(id, template);
        return "redirect:/templates";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        emailTemplateService.delete(id);
        return "redirect:/templates";
    }

    @PostMapping("/{id}/send")
    public String sendEmail(@PathVariable Long id) {
        emailTemplateService.sendEmail(id);
        return "redirect:/templates";
    }

    @PostMapping("/{id}/schedule")
    public String scheduleEmail(@PathVariable Long id, @RequestParam String cronExpression, @RequestParam(required = false) String timezone) {
        // 获取模板
        EmailTemplate template = emailTemplateService.findById(id);
        // 设置Cron表达式
        template.setCronExpression(cronExpression);
        // 确保模板是激活的
        template.setActive(true);
        // 保存模板
        emailTemplateService.update(id, template);
        // 调度任务
        emailTemplateService.scheduleEmail(id, cronExpression, timezone);
        return "redirect:/templates";
    }
    
    /**
     * 获取模板详情，包括模板信息和邮件内容
     */
    @GetMapping("/{id}/details")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getTemplateDetails(@PathVariable Long id) {
        try {
            // 获取模板信息
            EmailTemplate template = emailTemplateService.findById(id);
            System.out.println("获取模板详情，模板ID: " + id + ", 模板名称: " + template.getName());
            
            // 构建响应数据
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("id", template.getId());
            responseData.put("name", template.getName());
            responseData.put("subject", template.getSubject());
            responseData.put("recipientList", template.getRecipientList());
            responseData.put("content", template.getContent());
            responseData.put("cronExpression", template.getCronExpression());
            responseData.put("active", template.isActive());
            
            return ResponseEntity.ok(responseData);
        } catch (Exception e) {
            System.err.println("获取模板详情失败: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "获取模板详情失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }
} 